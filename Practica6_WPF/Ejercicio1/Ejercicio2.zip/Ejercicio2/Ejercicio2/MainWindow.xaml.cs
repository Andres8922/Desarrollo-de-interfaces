﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Ejercicio2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }


        private void CutCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e) { 

            e.CanExecute = (txtBox != null);
            
        }

        private void Cut_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            txtBox.Cut();
        }

        //---------------------------------------------------------------------------------------------


        private void PasteCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
                e.CanExecute = Clipboard.ContainsText(); //Si hay texto en el portapapeles
        }


        private void Paste_Executed(object sender, ExecutedRoutedEventArgs e)
        {

            txtBox.Paste();

        }
    }
}