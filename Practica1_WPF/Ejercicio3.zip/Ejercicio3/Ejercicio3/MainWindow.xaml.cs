﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Ejercicio3
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            CrearBoton();
            
        }


        public void CrearBoton() {

            Button bt = new Button(); //Creo el botón

            //Texto
            TextBlock tx = new TextBlock();
            tx.Text = "Prueba";
            tx.Foreground = Brushes.Green;


            TextBlock tx2 = new TextBlock();
            tx2.Text = "Prueba2";
            tx2.Foreground = Brushes.Blue;

            TextBlock tx3 = new TextBlock();
            tx3.Text = "Prueba3";

            //Wrap
            WrapPanel wp = new WrapPanel();

            wp.Children.Add(tx);
            wp.Children.Add(tx2);
            wp.Children.Add(tx3);

            bt.Content = wp;
            bt.FontWeight = FontWeights.Bold;
            bt.Height = 70;
            bt.Width = 70;
            bt.HorizontalAlignment = HorizontalAlignment.Center;
            bt.VerticalAlignment = VerticalAlignment.Center;


            if (this.FindName("Grid") is Grid Grid)
            {
                Grid.Children.Add(bt);
            }

        }

        
    }

    
}